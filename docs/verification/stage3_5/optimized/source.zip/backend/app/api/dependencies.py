import hmac
import ipaddress
from dataclasses import dataclass
from typing import Annotated, Literal

from fastapi import Depends, Header, Request

from app.core.errors import DomainError
from app.services.business import BusinessService
from app.services.workflow import WorkflowService


@dataclass(frozen=True)
class Principal:
    role: str
    user_id: int | None
    actor: str

    def require_owner(self, user_id: int) -> None:
        if self.role != "admin" and self.user_id != user_id:
            raise DomainError("FORBIDDEN", "不能访问其他用户的数据", 403)


def principal(
    request: Request,
    x_demo_role: Annotated[Literal["customer", "admin"], Header()] = "customer",
    x_demo_user_id: Annotated[int | None, Header(gt=0)] = None,
    x_demo_reviewer: Annotated[
        str, Header(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    ] = "local-admin",
    x_demo_token: Annotated[str | None, Header()] = None,
) -> Principal:
    """Explicit local role simulation; NOT production authentication."""
    try:
        local = request.client is not None and ipaddress.ip_address(request.client.host).is_loopback
    except ValueError:
        local = False
    if not local:
        raise DomainError("LOCAL_DEMO_ONLY", "业务接口仅允许本机演示连接", 403)
    expected = request.app.state.settings.demo_api_token.get_secret_value()
    if expected and not hmac.compare_digest(expected.encode(), (x_demo_token or "").encode()):
        raise DomainError("INVALID_DEMO_TOKEN", "演示访问令牌无效", 401)
    if x_demo_role == "customer" and x_demo_user_id is None:
        raise DomainError("DEMO_USER_REQUIRED", "请设置 X-Demo-User-Id 演示用户身份", 401)
    return Principal(
        x_demo_role,
        x_demo_user_id,
        f"admin:{x_demo_reviewer}" if x_demo_role == "admin" else f"user:{x_demo_user_id}",
    )


Current = Annotated[Principal, Depends(principal)]


def admin(identity: Current) -> Principal:
    if identity.role != "admin":
        raise DomainError("ADMIN_REQUIRED", "此操作需要本地演示管理员角色", 403)
    return identity


Admin = Annotated[Principal, Depends(admin)]


def business(request: Request) -> BusinessService:
    return request.app.state.business


def workflow(request: Request) -> WorkflowService:
    return request.app.state.workflow


Business = Annotated[BusinessService, Depends(business)]
Workflow = Annotated[WorkflowService, Depends(workflow)]
